importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
    const body = message.getBody(java.lang.String);
    const payload = JSON.parse(body)
    
    message.setProperty("Product", payload.Product);
    
    return message;
}